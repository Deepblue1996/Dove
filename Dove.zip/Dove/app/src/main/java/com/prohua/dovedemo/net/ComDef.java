package com.prohua.dovedemo.net;

/**
 * 地址 url - Address
 * Created by Deep on 2018/3/14 0014.
 */

public class ComDef {
    public final static String BASE_COM_URL = "https://www.axt18.com/";
}
